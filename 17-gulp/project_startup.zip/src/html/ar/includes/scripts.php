<!-- Swiper -->
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>


<!-- Custom JS Files -->
<script src="assets/js/custom.min.js"></script>

<!-- Intersection Observer -->
<script src="assets/js/vendors/intersection-observer.js"></script>