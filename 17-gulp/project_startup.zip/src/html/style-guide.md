

font families
--> Didot
font-family: 'Didot';
700
500

color: #FFFFFF;
       #000000

<!-- orange -->
color: #FF7C46;
 <!--gray  -->
 color: #2E2E2E;
 
 <!-- gray variation -->
 #CCCCCC
 #2E2E2E; 0.06;
 #2E2E2E; 0.8;

 #FBFBFB;
 #F0F0F0;


 h1 - 
 font-size: 80px;
 font-weight: 700;


 h2 -
 font-size: 48px;
 font-weight: 700;


 h3 -
 font-size: 35px;
 font-weight: 700;


 h4 - 
 font-size: 25px;
 font-weight: 700;

 h5 -
 font-size: 22px;
 
 
 h6 -
 font-size: 20px;



 p -
 font-size: 19px;
 font-weight: 500;
 line-height: 26px;


 btn 
 font-size: 18px;
 font-weight: 700;
 line-height: 28px;


 width="" height=""


 



 