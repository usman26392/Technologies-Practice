    <?php include 'includes/meta-top.php'; ?>
    <title>Terms Of Use</title>
    <?php include 'includes/meta.php'; ?>
</head>

<body class="">

    <!-- Loader -->
    <?php include 'includes/loader.php'; ?>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <main>

    </main>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>

</body>

</html>