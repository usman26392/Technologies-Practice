<!--Mobile Landscape Warning-->
<div id="portrait-warnning" class="alert-warnning" style="display: none">
    <p>For an optimal experience please<br> rotate your device to portrait mode</p>
</div>
<!--  -->

<!-- Loader -->
<div class="loader-first">
</div>
<!--  -->