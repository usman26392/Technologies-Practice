# 

# for installation npm packages
    npm i
    or
    npm install --save-dev


# commands
# --- for development ----
    gulp

# --- for production when all pages are done! now don't run this command due to some reason -----
    gulp --production


# RTL description example:
body {
    font-family: "Droid Sans", sans-serif #{"/*rtl:prepend:'Droid Arabic Kufi',*/"};
    font-size: 46px #{"/*rtl:8px*/"};
    direction: ltr;
}


