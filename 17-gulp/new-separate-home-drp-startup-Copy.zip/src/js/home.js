
console.log("usman");


function Check() {
    return console.log("you are working now !") 
}

Check();

